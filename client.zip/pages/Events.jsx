import React, { useState } from "react";

import { EventDummhy } from "../dummyData/event";
import Event_Card from "../components/events_card/Event_Card";
import Head from "next/head";
import PageTemplate from "../components/Templates/PageTemplate";
import Link from "next/link";

// This gets called on every request
export async function getServerSideProps() {
  // Fetch data from external API
  const res = await fetch(`${process.env.Url}/event`);
  const data = await res.json();

  // Pass data to the page via props
  return { props: { data } };
}

function Events(props) {
  const [EventData] = useState(props.data);

  return (
    <div>
      {/* head */}
      <Head>
        <title>Events</title>
        <meta
          name="description"
          content="This is the official site of VIP GROUP PVT.LTd."
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <PageTemplate>
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-primary text-4xl font-bold mt-4 md:mt-7 lg:mt-12 py-7">
            Events
          </div>

          {/* event categories section  */}
          <div className="flex flex-row items-center space-x-8">
            <p className="text-3xl">categories</p>
            <div className="border px-4 py-2 border-black rounded-full">
              <select className="lg:w-80 outline-none">
                <option className="p-4">All</option>
                <option className="p-4">All</option>
                <option className="p-4">All</option>
                <option className="p-4">All</option>
              </select>
            </div>
          </div>
          <hr className="mt-8 shadow" />

          {/* events card section  */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-8 lg:gap-10 xl:gap-12  my-12">
            {EventData.map((item) => {
              return (
                <Event_Card
                  key={item.id}
                  id={item.id}
                  title={item.event_title}
                  date={item.event_date}
                  location={item.event_location}
                  img={item.img}
                />
              );
            })}
          </div>
        </div>
      </PageTemplate>
    </div>
  );
}

export default Events;
