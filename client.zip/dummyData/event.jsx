export const EventDummhy=[
    {
       name:'This is the first event title which goes here',
       eventType:'all',
       eventLocation:'butwal',
       eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
    },
    {
        name:'This is the first event title which goes here',
        eventType:'new',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
     {
        name:'This is the first event title which goes here',
        eventType:'old',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
     {
        name:'This is the first event title which goes here',
        eventType:'all',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
     {
        name:'This is the first event title which goes here',
        eventType:'all',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
     {
        name:'This is the first event title which goes here',
        eventType:'all',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
     {
        name:'This is the first event title which goes here',
        eventType:'all',
        eventLocation:'butwal',
        eventDetail:'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
     },
]