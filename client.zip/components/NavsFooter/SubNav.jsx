import React from "react";
import { MdRememberMe } from "react-icons/md";

const SubNav = () => {
  return (
    <div>
      <MdRememberMe />
    </div>
  );
};

export default SubNav;
