export const staticAbout = {
  aboutUs:
    " VIP Group Pvt. Ltd (Visionary Idealist Personnel) is a company of dedicated and energetic youth Entreprenuers. Since 2019, we have been working on  several fields such as Event Management, Event Orgainzers, Entrepreneurship Development, Business Development Orientation, Motivational Seminars,Skills based training, Vocational trainings, Personality Development trainings, Leadership trainings, Job placements & so on. We Believe the concept of Learn, Earn, & Own. We train and provide platform for people to learn, provide multiple opportunities to Earn & also are providing different opportunities for Ownership of Dream life.",
};
// export
