"use strict";
exports.id = 891;
exports.ids = [891];
exports.modules = {

/***/ 7891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function Inputs(props) {
  var _props$options;

  let Inputed = 1;
  let className = `${props.errors ? "ring-2 ring-red-600" : "ring-0"}
  ${props.id === "login" ? "text-gray-800 bg-gray-200 outline-none text-sm flex-1 ring-0" : "md:h-10 px-2  py-1   rounded-lg resize-none  border border-gray-300 outline-none"}`;

  switch (props.type) {
    case "text":
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", _objectSpread(_objectSpread({
        type: props.type,
        placeholder: props.placeholder,
        name: props.usename
      }, props.register), {}, {
        className: className
      }));
      break;

    case "password":
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", _objectSpread(_objectSpread({
        type: props.type,
        placeholder: props.placeholder,
        name: props.usename
      }, props.register), {}, {
        className: className
      }));
      break;

    case "file":
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", _objectSpread(_objectSpread({
        type: props.type,
        name: props.usename
      }, props.register), {}, {
        className: className
      }));
      break;

    case "select":
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("select", _objectSpread(_objectSpread({
        name: props.usename
      }, props.register), {}, {
        className: className,
        children: (_props$options = props.options) === null || _props$options === void 0 ? void 0 : _props$options.map((val, i) => {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
            value: i === 0 ? "" : val.name,
            children: val.name
          }, i);
        })
      }));
      break;

    case "textarea":
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("textarea", _objectSpread(_objectSpread({
        rows: 5,
        cols: 10,
        name: props.usename
      }, props.register), {}, {
        className: `${className} md:h-32`
      }));
      break;

    default:
      Inputed = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h1", {
        children: "something went wrong see your render method and code again"
      });
      break;
  }

  return Inputed;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Inputs);

/***/ })

};
;