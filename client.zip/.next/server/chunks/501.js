"use strict";
exports.id = 501;
exports.ids = [501];
exports.modules = {

/***/ 5501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Templates_PageTemplate)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/NavsFooter/Navigations.json
const Navigations_namespaceObject = JSON.parse('[{"to":"/","id":"1","title":"Home"},{"to":"/About","id":"2","title":"About"},{"to":"/Projects","id":"3","title":"Projects"},{"to":"/Events","id":"4","title":"Events"},{"to":"/Services","id":"6","title":"Services"},{"to":"/Eventbooking","id":"7","title":"Event Booking"},{"to":"/Contact","id":"8","title":"Contact"}]');
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/PageEssentials/SocialMedia.jsx





function SocialMedia() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex items-center space-x-4",
    children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
      href: "http://",
      target: "_blank",
      rel: "noopener noreferrer",
      children: /*#__PURE__*/jsx_runtime_.jsx(fa_.FaFacebook, {
        className: "bg-white text-gray-800 p-1 rounded-full transition transform hover:scale-110"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: "http://",
      target: "_blank",
      rel: "noopener noreferrer",
      children: /*#__PURE__*/jsx_runtime_.jsx(fa_.FaYoutube, {
        className: "bg-white text-gray-800 p-1 rounded-full transition transform hover:scale-110"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: "http://",
      target: "_blank",
      rel: "noopener noreferrer",
      children: /*#__PURE__*/jsx_runtime_.jsx(fa_.FaInstagram, {
        className: "bg-white text-gray-800 p-1 rounded-full transition transform hover:scale-110"
      })
    })]
  });
}

/* harmony default export */ const PageEssentials_SocialMedia = (SocialMedia);
;// CONCATENATED MODULE: ./components/Footer/Footer.jsx







function Footer() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bg-gray-800 text-center pt-24 pb-10 text-white",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
      children: "VIP GROUP"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "my-8",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center space-x-4 lg:space-x-8 justify-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/Projects",
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "cursor-pointer font-semibold",
            children: "Finished Projects"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/Projects",
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "cursor-pointer font-semibold",
            children: "Running Projects"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/Projects",
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "cursor-pointer font-semibold",
            children: "Upcoming Projects"
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "container mx-auto px-4 lg:px-8 my-8 opacity-30",
      children: /*#__PURE__*/jsx_runtime_.jsx("hr", {})
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid grid-cols-2 gap-4 lg:flex lg:items-center lg:space-x-6 lg:justify-center",
      children: Navigations_namespaceObject.map((item, i) => /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: item.to,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "text-lg font-normal",
          children: item.title
        })
      }, i))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-center my-10 text-3xl",
      children: /*#__PURE__*/jsx_runtime_.jsx(PageEssentials_SocialMedia, {})
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "opacity-80 text-sm",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center space-x-4 justify-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "",
            children: "Terms & Conditions"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "",
            children: "Privacy Policy"
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "mt-4",
        children: "\xA9 Copyright 2022 under VIP GROP PVT. LTD."
      })]
    })]
  });
}

/* harmony default export */ const Footer_Footer = (Footer);
;// CONCATENATED MODULE: ./components/NavsFooter/Nav.jsx







function Nav() {
  const {
    0: mobileNav,
    1: setMobileNav
  } = (0,external_react_.useState)(false);
  const {
    0: clicked,
    1: setClicked
  } = (0,external_react_.useState)("");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bg-primary h-full",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: " container mx-auto px-4 lg:px-8  text-white flex items-center justify-between",
      children: [/*#__PURE__*/jsx_runtime_.jsx(fa_.FaBars, {
        className: "text-xl block lg:hidden",
        onClick: () => {
          setMobileNav(!mobileNav);
        }
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: "/",
        children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "font-bold cursor-pointer",
          children: "VIP GROUP"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "hidden  lg:flex flex-col lg:flex-row items-center space-x-6",
        children: Navigations_namespaceObject.map((item, i) => {
          if (!item.subNav) {
            return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: item.to,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "text-lg hover:text-blue-300",
                children: item.title
              })
            }, i);
          } else {
            return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "relative",
              onClick: () => setClicked(i),
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                children: [item.title, " "]
              }), i == clicked && item.subNav ? /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex flex-col divide-y-2 justify-center absolute  bg-primary shadow-md w-16 mx-auto border  gap-1 m-2 text-center active:bg-transparent",
                children: i == clicked && item.subNav ? item.subNav.map((val, i) => {
                  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                    href: val.to,
                    children: val.title
                  }, i);
                }) : null
              }) : null]
            });
          }
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `${mobileNav ? "block" : "hidden"} lg:hidden flex flex-col space-y-8 p-5 text-white`,
      children: Navigations_namespaceObject.map((item, i) => /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: item.to,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "text-lg",
          children: item.title
        })
      }, i))
    })]
  });
}

/* harmony default export */ const NavsFooter_Nav = (Nav);
;// CONCATENATED MODULE: ./components/Templates/PageTemplate.jsx






function PageTemplate(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(NavsFooter_Nav, {}), props.children, /*#__PURE__*/jsx_runtime_.jsx(Footer_Footer, {})]
  });
}

/* harmony default export */ const Templates_PageTemplate = (PageTemplate);

/***/ })

};
;