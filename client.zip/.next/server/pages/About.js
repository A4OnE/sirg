"use strict";
(() => {
var exports = {};
exports.id = 921;
exports.ids = [921];
exports.modules = {

/***/ 6343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const instance = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: "https://api.vipgroupnepal.com"
});
const ISSERVER = true; // console.log(localStorage);
// console.log(ISSERVER)
// console.log(process.browser)

if (false) {} else {// let data=localStorage.getItem('token');
  // console.log(data);
  // instance.defaults.headers.common['Authorization']='data';
}

instance.defaults.headers.common["Content-Type"] = "application/json";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (instance);

/***/ }),

/***/ 3569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




function BodCard({
  img,
  title,
  name
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "shadow-md m-10",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
        src: img,
        className: "  mx-auto h-96 mb-6 mt-6 object-cover rounded-md",
        srcSet: ""
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "py-6",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
          className: "text-2xl fond-bold text-center tracking-wider gap-2",
          children: name
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
          className: "text-xl font-thin text-center mt-2 tracking-wider gap-2",
          children: title
        })]
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BodCard);

/***/ }),

/***/ 3120:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_About),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/Templates/PageTemplate.jsx + 4 modules
var PageTemplate = __webpack_require__(5501);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./AXIOS/Axios-create.jsx
var Axios_create = __webpack_require__(6343);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/HappyCustomer/HappyCustomer.jsx






const HappyCustomer = () => {
  const data = [{
    nametitle: "MD of my Company Butwal",
    name: "Rabindra nath Taigore",
    img: "https://cdn.pixabay.com/photo/2016/02/10/21/57/heart-1192662__340.jpg",
    title: "Help us in our productivity",
    description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content "
  }, {
    nametitle: "MD of my Casfaasdfompany Butwal",
    name: "Rabinsadfasdfdra nath Taigore",
    img: "https://cdn.pixabay.com/photo/2016/02/10/21/57/heart-1192662__340.jpg",
    title: "Help us inasdf our productivity",
    description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content "
  }];
  const {
    0: body,
    1: setBody
  } = (0,external_react_.useState)([]);
  const {
    0: index,
    1: setIndex
  } = (0,external_react_.useState)(0);

  const getTestimonials = () => {
    Axios_create/* default.get */.Z.get("/testimonials").then(res => {
      setBody(res.data);
    }).catch(err => {
      console.log(err);
    });
  }; // component did mount ko kaam garcha yo code le


  (0,external_react_.useEffect)(() => {
    getTestimonials();
  }, []);

  let nextData = i => {
    console.log(i, body.length);

    if (i < body.length - 1) {
      setIndex(i + 1);
    } else {
      setIndex(0);
    }
  };

  let PrevData = i => {
    console.log(i, body.length);

    if (i !== 0) {
      setIndex(i - 1);
    } else {
      setIndex(0);
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "w-10/12\r fade-anim\r h-fit\r mt-10\r md:w-full \r lg:w-full lg:mx-10 lg:my-32\r ",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "ml-8",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-col mx-auto  text-center w-fit items-start ",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: " text-2xl md:text-4xl text-primary capitalize  md:font-bold font-semibold my-8 ",
          children: "happy customers"
        })
      })
    }), body.map((val, i) => {
      let image = `${"https://api.vipgroupnepal.com"}/images/${val.img}`;

      if (i === index) {
        return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "container mx-auto px-4 lg:px-8 grid grid-cols-1 gap-0 m-10\r md:grid-cols-1\r lg:grid-cols-3 lg:gap-0 lg:ml-4\r sm:gap-0 sm:text-center\r ",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full h-fit\r flex\r flex-col\r items-center\r justify-center\r ",
            children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
              src: image,
              alt: "",
              className: "\r h-48 w-48\r md:w-80 md:h-80\r lg:h-92 lg:w-92\r rounded-full\r "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex mt-4",
              children: [/*#__PURE__*/jsx_runtime_.jsx(fa_.FaLongArrowAltLeft, {
                onClick: () => PrevData(i),
                className: "mr-4 text-4xl cursor-pointer"
              }), /*#__PURE__*/jsx_runtime_.jsx(fa_.FaLongArrowAltRight, {
                onClick: () => nextData(i),
                className: " text-4xl placeholder-opacity-50 cursor-pointer"
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "lg:col-span-2 lg:ml-28 text-center",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "h-fit w-full  object-cover tracking-wider italic mt-8\r md:w-full\r lg:w-11/12 lg:text-lg\r sm:w-full line-clamp-10\r ",
              children: ["\u201C", val.feedback, "\u201D"]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "text-gray-500  capitalize font-bold tg mt-6 text-center\r lg:mt-4  \r md:text-2xl \r text-base\r ",
                children: val.name
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: " text-center text-xs  md:text-lg",
                children: val.job_title
              })]
            })]
          })]
        }, i);
      }
    })]
  });
};

/* harmony default export */ const HappyCustomer_HappyCustomer = (HappyCustomer);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./components/Ourclients/OurClients.jsx





function OurClients() {
  const {
    0: data,
    1: setData
  } = (0,external_react_.useState)([]);
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    const fetch = async () => {
      setLoading(true);
      await external_axios_default().get(`${"https://api.vipgroupnepal.com"}/clients`).then(res => {
        setLoading(false);
        setData(res.data);
      });
    };

    fetch();
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "text-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "text-primary",
        children: "We Have Worked With..."
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "font-medium text-lg text-gray-800",
        children: "Our Clients"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-center my-24",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",
        children: data.map(item => /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mx-auto",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: item.link,
            target: "_blank",
            rel: "noopener noreferrer",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: `${"https://api.vipgroupnepal.com"}/images/${item.img}`,
              alt: item.id
            })
          })
        }, item.id))
      })
    })]
  });
}

/* harmony default export */ const Ourclients_OurClients = (OurClients);
// EXTERNAL MODULE: ./components/Cards/BodCard.jsx
var BodCard = __webpack_require__(3569);
;// CONCATENATED MODULE: external "react-player"
const external_react_player_namespaceObject = require("react-player");
var external_react_player_default = /*#__PURE__*/__webpack_require__.n(external_react_player_namespaceObject);
;// CONCATENATED MODULE: ./components/Sections/AboutVideoSection.jsx





function AboutVideoSection() {
  const {
    0: data,
    1: setdata
  } = (0,external_react_.useState)("");
  console.log(typeof data);
  (0,external_react_.useEffect)(() => {
    const fetch = async () => {
      await external_axios_default().get(`${"https://api.vipgroupnepal.com"}/videos`).then(res => {
        var _res$data$, _res$data$2;

        console.log((_res$data$ = res.data[1]) === null || _res$data$ === void 0 ? void 0 : _res$data$.video);
        setdata(`${"https://api.vipgroupnepal.com"}/images/${(_res$data$2 = res.data[0]) === null || _res$data$2 === void 0 ? void 0 : _res$data$2.video}`);
      });
    };

    fetch();
  }, []);
  return (
    /*#__PURE__*/
    // //     <video width="400" controls>
    // //     <source src="mov_bbb.mp4" type="video/mp4">
    // //     <source src="mov_bbb.ogg" type="video/ogg">
    // //     Your browser does not support HTML video.
    // //   </video>
    // <video controls style={{ height: "100%" }}>
    //   <source src={`${data}`} type="video/mp4" />
    //   <source src={`${data}`} type="video/ogg" />
    // </video>
    jsx_runtime_.jsx((external_react_player_default()), {
      url: `${data}`,
      controls: true,
      volume: 0,
      style: {
        height: "100%"
      }
    })
  );
}

/* harmony default export */ const Sections_AboutVideoSection = (AboutVideoSection);
;// CONCATENATED MODULE: ./pages/About.jsx






 // This gets called on every request

async function getServerSideProps() {
  // Fetch data from external API
  const res = await fetch(`${"https://api.vipgroupnepal.com"}/bod`);
  const data = await res.json(); // Pass data to the page via props

  return {
    props: {
      data
    }
  };
}





function About({
  data
}) {
  var _data$slice;

  const {
    0: Data,
    1: setData
  } = (0,external_react_.useState)([]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "About Us"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "title",
        content: "About VIP GROUP PVT.LTD."
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "VIP Group Pvt. Ltd (Visionary Idealist Personnel) is a company of dedicated and energetic youth Entreprenuers. Since 2019, we have been working on several fields such asEvent Management, Event Orgainzers, Entrepreneurship Development, Business Development Orientation, Motivational Seminars,Skills based training, Vocational trainings, Personality Development trainings, Leadership trainings, Job placements, Website Development & so on."
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/logo.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:url",
        content: "https://vipgroupnepal.com/About"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:title",
        content: "About VIP Group Pvt. Ltd "
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:description",
        content: "VIP Group Pvt. Ltd (Visionary Idealist Personnel) is a company of dedicated and energetic youth Entreprenuers. Since 2019, we have been working on several fields such asEvent Management, Event Orgainzers, Entrepreneurship Development, Business Development Orientation, Motivational Seminars,Skills based training, Vocational trainings, Personality Development trainings, Leadership trainings, Job placements, Website Development & so on."
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:image",
        content: "https://api.vipgroupnepal.com/images/vip.jpg"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:url",
        content: "https://vipgroupnepal.com/About"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:title",
        content: "About VIP Group Pvt. Ltd"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:description",
        content: "VIP Group Pvt. Ltd (Visionary Idealist Personnel) is a company of dedicated and energetic youth Entreprenuers. Since 2019, we have been working on several fields such asEvent Management, Event Orgainzers, Entrepreneurship Development, Business Development Orientation, Motivational Seminars,Skills based training, Vocational trainings, Personality Development trainings, Leadership trainings, Job placements, Website Development & so on."
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:image",
        content: "https://api.vipgroupnepal.com/images/vip.jpg"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(PageTemplate/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container mx-auto px-4 lg:px-8",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: " flex flex-col lg:flex-row w-full mt-24 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lg:flex-1 ",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: " h-96 lg:h-full lg:m-10 flex justify-center items-center",
              children: /*#__PURE__*/jsx_runtime_.jsx(Sections_AboutVideoSection, {})
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex-1 mt-10 mx-5   p-2",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "flex flex-col mx-auto  lg:mx-0 text-center  w-fit items-start  ",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
                className: " text-2xl md:text-4xl text-primary capitalize font-bold ",
                children: ["who we are?", " "]
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "w-full my-4  -tracking-tight leading-7 lg:leading-7 text-lg text-justify",
              children: ["VIP Group Pvt. Ltd (Visionary Idealist Personnel) is a company of dedicated and energetic youth Entreprenuers. Since 2019, we have been working on several fields such as", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: " ml-1 font-medium  text-justify",
                children: "Event Management, Event Orgainzers, Entrepreneurship Development, Business Development Orientation, Motivational Seminars,Skills based training, Vocational trainings, Personality Development trainings, Leadership trainings, Job placements, Website Development & so on."
              }), "We Believe the concept of Learn, Earn, & Own. We train and provide platform for people to learn, provide multiple opportunities to Earn & also are providing different opportunities for Ownership of Dream life."]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "pt-10  h-fit flex justify-center md:justify-center sm:justify-center lg:justify-start",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/Contact",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "border-2 font-semibold border-primary w-fit flex items-center  px-4 h-10 text-primary rounded-full cursor-pointer",
                  children: "Contact us"
                })
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "bg-gray-50 p-4 lg:p-24 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 my-24",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
              className: "text-5xl lg:text-8xl text-primary",
              children: ["Our ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), " Mission ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), " & Vision"]
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "mt-16",
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "font-bold text-gray-700 text-2xl",
              children: "Our Vision"
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "my-8 text-gray-800 text-justify",
              children: "To establish as a leading company of Nepal in our specific field by connecting, inspiring youths and transforming them to live a life of entrepreneurial on their own terms."
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "font-bold text-gray-700 text-2xl",
              children: "Our Mission"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "my-8 text-gray-800 text-justify",
              children: ["To provide a platform for youths to learn desired skills, assist them in putting those skills to work, and guide in taking control of their dream lives.", " "]
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-primary text-center gap-8 my-14 text-4xl tracking-wider font-bold",
            children: "Board of Directors"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/Aboutus/BOD",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: " text-center btn-primary rounded-full flex items-center justify-center w-32 mx-auto",
              children: ["view all ", /*#__PURE__*/jsx_runtime_.jsx(bs_.BsFillArrowRightCircleFill, {
                className: "ml-2"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "grid lg:grid-cols-3 gap-8",
            children: (_data$slice = data.slice(0, 3)) === null || _data$slice === void 0 ? void 0 : _data$slice.map(item => /*#__PURE__*/jsx_runtime_.jsx(BodCard/* default */.Z, {
              img: `${"https://api.vipgroupnepal.com"}/images/${item.img}`,
              name: item.name,
              title: item.job_title
            }, item.id))
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full flex justify-center items-center flex-col",
          children: [/*#__PURE__*/jsx_runtime_.jsx(HappyCustomer_HappyCustomer, {}), /*#__PURE__*/jsx_runtime_.jsx(Ourclients_OurClients, {})]
        })]
      })
    })]
  });
}

/* harmony default export */ const pages_About = (About);

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,501], () => (__webpack_exec__(3120)));
module.exports = __webpack_exports__;

})();