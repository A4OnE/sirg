"use strict";
(() => {
var exports = {};
exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 3687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_Events),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./dummyData/event.jsx
const EventDummhy = [{
  name: 'This is the first event title which goes here',
  eventType: 'all',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'new',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'old',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'all',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'all',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'all',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}, {
  name: 'This is the first event title which goes here',
  eventType: 'all',
  eventLocation: 'butwal',
  eventDetail: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.'
}];
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/events_card/Event_Card.jsx







function Event_Card({
  id,
  title,
  date,
  location,
  img
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "border rounded-md overflow-hidden cursor-text shadow-lg transition-transform duration-500  hover:scale-105",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "h-96 bg-cover",
      style: {
        backgroundImage: `linear-gradient(0deg, rgba(2,0,36,0.8995973389355743) 20%, rgba(1,85,124,0.6979166666666667) 55%, rgba(0,179,221,0.3029586834733894) 80%, rgba(0,212,255,0) 100%), url(${"https://api.vipgroupnepal.com"}/images/${img})`
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 pt-52",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/Event/" + id,
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-2xl font-bold  cursor-pointer text-white line-clamp-2",
            children: title
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "my-4",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-white  flex flex-row text-base items-center my-2 ",
            children: [/*#__PURE__*/jsx_runtime_.jsx(md_.MdDateRange, {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "ml-1  text-black-400",
              children: date
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-white flex flex-row text-base items-center my-2 ",
            children: [/*#__PURE__*/jsx_runtime_.jsx(io5_.IoLocationSharp, {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "ml-1  text-black-400",
              children: location
            })]
          })]
        })]
      })
    })
  });
}

/* harmony default export */ const events_card_Event_Card = (Event_Card);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Templates/PageTemplate.jsx + 4 modules
var PageTemplate = __webpack_require__(5501);
;// CONCATENATED MODULE: ./pages/Events.jsx





 // This gets called on every request



async function getServerSideProps() {
  // Fetch data from external API
  const res = await fetch(`${"https://api.vipgroupnepal.com"}/event`);
  const data = await res.json(); // Pass data to the page via props

  return {
    props: {
      data
    }
  };
}

function Events(props) {
  const {
    0: EventData
  } = (0,external_react_.useState)(props.data);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Events"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "title",
        content: "Events of VIP VIP GROUP PVT.LTD."
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "We organise number of events in different sector of businesses growth and personnal growth such as:personality developement, how to sell anything?, how to grow business after covid etc"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/logo.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:url",
        content: "https://vipgroupnepal.com/Events"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:title",
        content: "Events of VIP VIP Group Pvt. Ltd "
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:description",
        content: "We organise number of events in different sector of businesses growth and personnal growth such as:personality developement, how to sell anything?, how to grow business after covid etc"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:image",
        content: "https://api.vipgroupnepal.com/images/vip.jpg"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:url",
        content: "https://vipgroupnepal.com/Events"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:title",
        content: "Events of VIP VIP Group Pvt. Ltd"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:description",
        content: "We organise number of events in different sector of businesses growth and personnal growth such as:personality developement, how to sell anything?, how to grow business after covid etc"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:image",
        content: "https://api.vipgroupnepal.com/images/vip.jpg"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(PageTemplate/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container mx-auto px-4 lg:px-8",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-primary text-center text-6xl font-bold mt-4 md:mt-7 lg:mt-12 py-7",
          children: "Events"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-gray-800 font-medium text-center",
          children: "All the events done by VIP Group"
        }), /*#__PURE__*/jsx_runtime_.jsx("hr", {
          className: "mt-8 shadow"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-8 lg:gap-10 xl:gap-12  my-12",
          children: EventData.map(item => {
            return /*#__PURE__*/jsx_runtime_.jsx(events_card_Event_Card, {
              id: item.id,
              title: item.event_title,
              date: item.event_date,
              location: item.event_location,
              img: item.img
            }, item.id);
          })
        })]
      })
    })]
  });
}

/* harmony default export */ const pages_Events = (Events);

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,501], () => (__webpack_exec__(3687)));
module.exports = __webpack_exports__;

})();