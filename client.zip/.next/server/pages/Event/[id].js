"use strict";
(() => {
var exports = {};
exports.id = 889;
exports.ids = [889];
exports.modules = {

/***/ 33:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/Templates/PageTemplate.jsx + 4 modules
var PageTemplate = __webpack_require__(5501);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__(9931);
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Sliders/GallerySlider.jsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function GallerySlider({
  data
}) {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "p-10",
    children: /*#__PURE__*/jsx_runtime_.jsx((external_react_slick_default()), _objectSpread(_objectSpread({}, settings), {}, {
      ariaHideApp: false,
      children: data.map(item => /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: `${"https://api.vipgroupnepal.com"}/images/${item.img}`,
          className: "h-96 lg:h-128 w-full object-cover",
          srcSet: ""
        })
      }, item.id))
    }))
  });
}

/* harmony default export */ const Sliders_GallerySlider = (GallerySlider);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./components/Gallery/EventGallery.jsx








function EventGallery({
  id
}) {
  const [modalIsOpen, setIsOpen] = external_react_default().useState(false);
  const customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      height: "90%",
      width: "90%",
      bottom: "auto",
      padding: "0px",
      background: "transparent",
      marginRight: "-50%",
      border: "none",
      transform: "translate(-50%, -50%)"
    }
  };
  const {
    0: images,
    1: setImages
  } = (0,external_react_.useState)([]);
  console.log("images", images);
  (0,external_react_.useEffect)(() => {
    const fetch = async () => {
      await external_axios_default().get(`${"https://api.vipgroupnepal.com"}/eventgallery/onEvent/${id}`).then(res => {
        setImages(res.data.gallery);
      });
    };

    fetch();
  }, [id]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "p-4",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
      className: "text-gray-800",
      children: "Event Gallery"
    }), /*#__PURE__*/jsx_runtime_.jsx("hr", {
      className: "my-4"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid grid-cols-2 gap-4",
      children: images.map(item => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bg-gray-600 h-32 w-full cursor-pointer",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: `${"https://api.vipgroupnepal.com"}/images/${item.img}`,
          alt: "",
          className: "w-full h-full object-cover rounded shadow-md ",
          onClick: () => {
            setIsOpen(true);
          }
        })
      }, item.id))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_modal_default()), {
        isOpen: modalIsOpen,
        style: customStyles,
        contentLabel: "Example Modal",
        className: "",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: () => {
            setIsOpen(false);
          },
          className: "absolute font-bold right-1 lg:right-4 top-5 lg:top-5 z-10 bg-white p-1 rounded-full shadow-md",
          children: /*#__PURE__*/jsx_runtime_.jsx(ai_.AiOutlineClose, {
            className: "font-bold text-4xl"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Sliders_GallerySlider, {
          data: images
        })]
      })
    })]
  });
}

/* harmony default export */ const Gallery_EventGallery = (EventGallery);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/Event/[id].jsx









async function getServerSideProps(context) {
  // Fetch data from external API
  const {
    id
  } = context.query;
  const res = await fetch(`${"https://api.vipgroupnepal.com"}/event/${id}`);
  const data = await res.json(); // Pass data to the page via props

  return {
    props: {
      data
    }
  };
}

function EventDetails(props) {
  var _props$data$event$, _props$data$event$2, _props$data$event$3, _props$data$event$4, _props$data$event$5, _props$data$event$6, _props$data$event$7, _props$data$event$8, _props$data$event$9, _props$data$event$10, _props$data$event$11, _data$, _data$2, _data$3, _data$4, _data$5, _data$6;

  const {
    0: data,
    1: setData
  } = (0,external_react_.useState)(props.data.event);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: (_props$data$event$ = props.data.event[0]) === null || _props$data$event$ === void 0 ? void 0 : _props$data$event$.event_title
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "title",
        content: (_props$data$event$2 = props.data.event[0]) === null || _props$data$event$2 === void 0 ? void 0 : _props$data$event$2.event_title
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: (_props$data$event$3 = props.data.event[0]) === null || _props$data$event$3 === void 0 ? void 0 : _props$data$event$3.event_details
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/logo.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:url",
        content: `https://vipgroupnepal.com/Event/${(_props$data$event$4 = props.data.event[0]) === null || _props$data$event$4 === void 0 ? void 0 : _props$data$event$4.id}`
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:title",
        content: (_props$data$event$5 = props.data.event[0]) === null || _props$data$event$5 === void 0 ? void 0 : _props$data$event$5.event_title
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:description",
        content: (_props$data$event$6 = props.data.event[0]) === null || _props$data$event$6 === void 0 ? void 0 : _props$data$event$6.event_details
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:image",
        content: `https://api.vipgroupnepal.com/images/${(_props$data$event$7 = props.data.event[0]) === null || _props$data$event$7 === void 0 ? void 0 : _props$data$event$7.img}`
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:type",
        content: "website"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:url",
        content: `https://vipgroupnepal.com/Event/${(_props$data$event$8 = props.data.event[0]) === null || _props$data$event$8 === void 0 ? void 0 : _props$data$event$8.id}`
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:title",
        content: (_props$data$event$9 = props.data.event[0]) === null || _props$data$event$9 === void 0 ? void 0 : _props$data$event$9.event_title
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:description",
        content: (_props$data$event$10 = props.data.event[0]) === null || _props$data$event$10 === void 0 ? void 0 : _props$data$event$10.event_details
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "twitter:image",
        content: `https://api.vipgroupnepal.com/images/${(_props$data$event$11 = props.data.event[0]) === null || _props$data$event$11 === void 0 ? void 0 : _props$data$event$11.img}`
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(PageTemplate/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container mx-auto px-4 lg:px-8 pt-10 pb-24",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "lg:grid lg:grid-cols-12 gap-8",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "col-span-8",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-5xl leading-12",
              children: (_data$ = data[0]) === null || _data$ === void 0 ? void 0 : _data$.event_title
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex items-center space-x-4 font-semibold text-gray-800",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center space-x-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx(io5_.IoLocation, {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: (_data$2 = data[0]) === null || _data$2 === void 0 ? void 0 : _data$2.event_location
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center space-x-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx(md_.MdDateRange, {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: (_data$3 = data[0]) === null || _data$3 === void 0 ? void 0 : _data$3.event_date
                })]
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "h-128 w-full my-8 object-cover",
                style: {
                  backgroundImage: `url(${"https://api.vipgroupnepal.com"}/images/${(_data$4 = data[0]) === null || _data$4 === void 0 ? void 0 : _data$4.img})`,
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "cover",
                  backgroundPosition: "center"
                }
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "text-lg leading-9 text-justify mb-10",
              children: (_data$5 = data[0]) === null || _data$5 === void 0 ? void 0 : _data$5.event_details
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-span-4 shadow-md my-5 h-screen overflow-auto sticky top-4",
            children: /*#__PURE__*/jsx_runtime_.jsx(Gallery_EventGallery, {
              id: (_data$6 = data[0]) === null || _data$6 === void 0 ? void 0 : _data$6.id
            })
          })]
        })
      })
    })]
  });
}

/* harmony default export */ const _id_ = (EventDetails);

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 9931:
/***/ ((module) => {

module.exports = require("react-modal");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,501], () => (__webpack_exec__(33)));
module.exports = __webpack_exports__;

})();