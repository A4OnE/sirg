module.exports = {
  reactStrictMode: true,

  env: {
    Url: "https://api.vipgroupnepal.com",
  },
};
